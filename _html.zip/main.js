// Updated JavaScript for Modal Functionality and UI Enhancements

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener("click", function(e) {
    e.preventDefault();
    document.querySelector(this.getAttribute("href")).scrollIntoView({
      behavior: "smooth"
    });
  });
});

// Back to top button behavior
const backToTopBtn = document.createElement('button');
backToTopBtn.id = "backToTopBtn";
backToTopBtn.textContent = "↑ Top";
Object.assign(backToTopBtn.style, {
  position: "fixed",
  bottom: "20px",
  right: "20px",
  display: "none",
  padding: "10px",
  zIndex: "1000",
  background: "orange",
  color: "white",
  border: "none",
  borderRadius: "5px",
  cursor: "pointer",
  fontSize: "14px"
});
document.body.appendChild(backToTopBtn);

window.addEventListener("scroll", () => {
  backToTopBtn.style.display = window.scrollY > 300 ? "block" : "none";
});

backToTopBtn.addEventListener("click", () => {
  window.scrollTo({ top: 0, behavior: "smooth" });
});

// Fade-in on scroll
const faders = document.querySelectorAll('.fade-in');
const appearOptions = { threshold: 0.1, rootMargin: "0px 0px -50px 0px" };
const appearOnScroll = new IntersectionObserver((entries, observer) => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    entry.target.classList.add("appear");
    observer.unobserve(entry.target);
  });
}, appearOptions);
faders.forEach(fader => {
  appearOnScroll.observe(fader);
});

// Dynamic year in footer
const yearEl = document.getElementById("year");
if (yearEl) {
  yearEl.textContent = new Date().getFullYear();
}

// Scroll Progress Bar
const progressBar = document.createElement('div');
Object.assign(progressBar.style, {
  position: "fixed",
  top: 0,
  left: 0,
  height: "5px",
  background: "orange",
  width: "0%",
  zIndex: 9999
});
document.body.prepend(progressBar);

window.addEventListener("scroll", () => {
  const scrolled = (window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100;
  progressBar.style.width = `${scrolled}%`;
});

// Auto Dark Mode
function applyTheme() {
  if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    document.body.classList.add("dark-mode");
  } else {
    document.body.classList.remove("dark-mode");
  }
}
applyTheme();
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme);

// Animated Counters
document.addEventListener("DOMContentLoaded", () => {
  const counters = document.querySelectorAll('[data-counter]');
  counters.forEach(counter => {
    const target = parseInt(counter.getAttribute('data-counter'));
    if (!isNaN(target)) animateCounter(counter, target);
  });
});

function animateCounter(el, target, duration = 1500) {
  let start = 0;
  const increment = target / (duration / 16);
  function update() {
    start += increment;
    if (start >= target) {
      el.textContent = target;
    } else {
      el.textContent = Math.floor(start);
      requestAnimationFrame(update);
    }
  }
  update();
}

// Modal Logic
document.addEventListener("DOMContentLoaded", () => {
  const openModal = (modal) => {
    if (modal) {
      modal.style.display = "block";
      document.body.style.overflow = "hidden";
    }
  };

  const closeModal = (modal) => {
    modal.style.display = "none";
    document.body.style.overflow = "auto";
  };

  document.querySelectorAll("[data-modal-target]").forEach(card => {
    card.addEventListener("click", () => {
      const target = document.querySelector(card.getAttribute("data-modal-target"));
      openModal(target);
    });
  });

  document.querySelectorAll(".close-button").forEach(button => {
    button.addEventListener("click", () => {
      const modal = button.closest(".modal");
      closeModal(modal);
    });
  });

  window.addEventListener("click", (event) => {
    document.querySelectorAll(".modal").forEach(modal => {
      if (event.target === modal) {
        closeModal(modal);
      }
    });
  });
});
